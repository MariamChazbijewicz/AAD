package com.example.ffsmartfridge

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
